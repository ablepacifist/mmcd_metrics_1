# MMCD Dashboard Deployment Instructions

## Deployment Options

### Option 1: Standard Docker Deployment (Default)
```bash
# Extract package
tar -xzf mmcd-dashboard-deploy.tar.gz
cd mmcd-dashboard-deploy

# Deploy with default settings (port 3838)
docker-compose up -d
```

### Option 2: Custom Port Deployment
```bash
# Set custom port using environment variable
echo "HOST_PORT=8080" > .env
docker-compose up -d

# Or modify docker-compose.yml directly and change:
# - "${HOST_PORT:-3838}:3838" to - "YOUR_PORT:3838"
```

### Option 3: Non-Root User Deployment (Recommended for Shared Systems)
```bash
# Use the non-root configuration
docker-compose -f docker-compose-nonroot.yml up -d

# Or with custom port:
echo "HOST_PORT=8080" > .env
docker-compose -f docker-compose-nonroot.yml up -d
```

### Option 4: Manual Installation (No Docker/Root Required)

If Docker is not available or not preferred:

#### Prerequisites
- R 4.0+ installed
- User has permission to install R packages in their home directory

#### Installation Steps
```bash
# 1. Extract package
tar -xzf mmcd-dashboard-deploy.tar.gz
cd mmcd-dashboard-deploy

# 2. Install R packages (user-level, no sudo required)
R -e "install.packages(c('shiny', 'shinydashboard', 'shinyWidgets', 'DBI', 'RPostgres', 'dplyr', 'ggplot2', 'lubridate', 'scales', 'stringr', 'DT', 'plotrix', 'dtplyr', 'vroom', 'tidyverse', 'classInt', 's2', 'sf', 'leaflet', 'terra', 'textshaping', 'units', 'raster', 'plotly', 'purrr', 'tibble'), repos='https://cran.rstudio.com/')"

# 3. Run on custom port (e.g., 8080)
R -e "shiny::runApp('.', host='0.0.0.0', port=8080)"

# 4. Or run individual apps:
cd apps/mosquito-monitoring
R -e "shiny::runApp('.', host='0.0.0.0', port=8080)"
```

## Port Configuration Examples

### Common Port Options
- **3838**: Standard Shiny Server port
- **8080**: Common alternative web port
- **9999**: High-numbered port (often unrestricted)
- **8888**: Jupyter-style port
- **3000**: Node.js-style port

### Environment Variable Configuration
Create a `.env` file in the deployment directory:
```bash
# Custom port
HOST_PORT=8080

# Custom user/group (for non-root deployment)
USER_ID=1000
GROUP_ID=1000
```

## Reverse Proxy Setup

### Apache (any port)
```apache
# For port 8080 deployment
ProxyPass /mmcd-dashboard/ http://localhost:8080/
ProxyPassReverse /mmcd-dashboard/ http://localhost:8080/
ProxyPreserveHost On
```

### Nginx (any port)
```nginx
# For port 8080 deployment
location /mmcd-dashboard/ {
    proxy_pass http://localhost:8080/;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "upgrade";
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
}
```

### Subdomain Setup
```nginx
# For subdomain setup (mmcd.your-domain.com)
server {
    listen 80;
    server_name mmcd.your-domain.com;
    
    location / {
        proxy_pass http://localhost:8080/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
    }
}
```

## Security Considerations

### Non-Root Deployment Benefits
- Container runs as user ID 1000 (not root)
- Limited file system access
- Reduced attack surface
- Suitable for shared hosting environments

### Network Security
- Dashboard only needs outbound access to rds-readonly.mmcd.org:5432
- No inbound database connections required
- Read-only database credentials
- No file upload capabilities

### Firewall Configuration
```bash
# Only allow outbound database connections
sudo ufw allow out 5432/tcp

# Allow inbound on your chosen port
sudo ufw allow 8080/tcp  # or your chosen port
```

## Database Configuration

The applications connect to:
- **Host**: rds-readonly.mmcd.org
- **Database**: mmcd_data
- **User**: mmcd_read
- **Password**: mmcd2012
- **Port**: 5432

**Network Requirements**: The host system must be able to reach `rds-readonly.mmcd.org:5432`

## Troubleshooting

### Docker Issues
```bash
# Check logs
docker-compose logs mmcd-dashboard

# Restart
docker-compose restart

# Rebuild (if needed)
docker-compose build --no-cache

# Check which ports are in use
docker-compose ps
```

### Port Conflicts
```bash
# Check if port is already in use
netstat -tlnp | grep :8080
# or
ss -tlnp | grep :8080

# Find available ports
for port in {8080..8090}; do
    nc -z localhost $port || echo "Port $port is available"
done
```

### Database Connectivity
```bash
# Test database connection
telnet rds-readonly.mmcd.org 5432

# Check if blocked by firewall
curl -v telnet://rds-readonly.mmcd.org:5432
```

### Manual Installation Issues
```bash
# Check R package installation
R -e "library(shiny); library(DBI); library(RPostgres)"

# Run with verbose output
R -e "options(shiny.trace=TRUE); shiny::runApp('.', port=8080)"
```

## Advanced Configuration

### Running Multiple Instances
```bash
# Run on different ports for different environments
# Development
echo "HOST_PORT=8080" > .env.dev
docker-compose --env-file .env.dev up -d

# Staging  
echo "HOST_PORT=8081" > .env.staging
docker-compose --env-file .env.staging -p mmcd-staging up -d
```

### Custom Resource Limits
Add to docker-compose.yml:
```yaml
services:
  mmcd-dashboard:
    # ... existing config ...
    deploy:
      resources:
        limits:
          memory: 2G
          cpus: '1.0'
```

## Support
- **Technical Issues**: Contact MMCD IT team
- **Database Access**: Contact Alex directly  
- **Application Bugs**: Submit GitHub issue

## Quick Reference Commands

```bash
# Standard deployment (port 3838)
docker-compose up -d

# Custom port deployment (port 8080)
echo "HOST_PORT=8080" > .env && docker-compose up -d

# Non-root deployment (port 8080, safer for shared systems)
echo "HOST_PORT=8080" > .env && docker-compose -f docker-compose-nonroot.yml up -d

# Manual R deployment (no Docker)
R -e "shiny::runApp('.', host='0.0.0.0', port=8080)"

# Check status
docker-compose ps

# View logs
docker-compose logs -f

# Stop
docker-compose down
```
